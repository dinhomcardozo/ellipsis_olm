CREATE TABLE Stages (
    stage_id SERIAL PRIMARY KEY,                   -- ID do estágio
    stage_name VARCHAR(15) NOT NULL,               -- Nome do estágio
    stage_description TEXT,                        -- Descrição do estágio
    num_active_opps INT DEFAULT 0,                 -- Contagem de oportunidades ativas
    num_contacts INT DEFAULT 0                     -- Contagem de contatos
);