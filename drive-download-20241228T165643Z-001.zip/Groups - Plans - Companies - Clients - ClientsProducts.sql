CREATE TABLE Groups (
    group_id SERIAL PRIMARY KEY, -- Chave primária autoincrementada
    company_ids INTEGER[] NOT NULL, -- Array com IDs das companies presentes no grupo
    CONSTRAINT fk_company_ids FOREIGN KEY (company_ids) REFERENCES Companies(company_id) -- Relacionamento com Companies
);	

-- Tabela de Plans
CREATE TABLE Plans (
    plan_id SERIAL PRIMARY KEY, -- Número ordenado do plano
    plan_name VARCHAR(40) NOT NULL, -- Nome do plano
    plan_description TEXT, -- Descrição do plano
    plan_status VARCHAR(10) CHECK (plan_status IN ('ativo', 'inativo')), -- Status do plano (ativo ou inativo)
    plan_validity TIMESTAMP, -- Data e hora de validade do plano
    plan_price NUMERIC(10, 2), -- Preço do plano
    created_by VARCHAR(100), -- Nome do usuário que criou o plano
    updated_by TIMESTAMP, -- Data e hora da última atualização
    num_plan_groups INTEGER, -- Número de grupos no plano (contagem de group_id na tabela Groups)
    num_plan_clients INTEGER, -- Número de clientes no plano (contagem de client_id na tabela Clients)
    CONSTRAINT fk_plan_groups FOREIGN KEY (num_plan_groups) REFERENCES Groups(group_id), -- Relacionamento com Groups
    CONSTRAINT fk_plan_clients FOREIGN KEY (num_plan_clients) REFERENCES Clients(client_id) -- Relacionamento com Clients
);

-- Tabela de Empresas
CREATE TABLE Companies (
    company_id SERIAL PRIMARY KEY, -- Chave primária autoincrementada
    company_name VARCHAR(255) NOT NULL, -- Razão Social
    company_cnpj VARCHAR(18) NOT NULL UNIQUE, -- CNPJ único
    address VARCHAR(50), -- Endereço
    address_number INTEGER, -- Número do endereço
    country CHAR(3), -- País (ISO 3166-1 Alpha-3)
    state CHAR(2), -- Estado (UF)
    city VARCHAR(40), -- Cidade
    segment_id INTEGER NOT NULL REFERENCES Segments(segment_id), -- Referência ao Segmento
    subsegment_id INTEGER REFERENCES SubSegments(subsegment_id), -- Referência ao Subsegmento
    tax_regime_id INTEGER NOT NULL REFERENCES TaxRegime(tax_regime_id), -- Regime tributário
    group_id INTEGER -- Relacionamento com grupo (opcional)
);

-- Tabela de Clientes
CREATE TABLE Clients (
    client_id SERIAL PRIMARY KEY, -- Chave primária autoincrementada
    plan_id INTEGER NOT NULL REFERENCES Plans(plan_id), -- Plano do cliente
    num_client_users INTEGER DEFAULT 0, -- Contagem de usuários cadastrados
    cnpj VARCHAR(18) NOT NULL UNIQUE, -- CNPJ único
    tax_regime_id INTEGER NOT NULL REFERENCES TaxRegime(tax_regime_id), -- Regime tributário
    segment_id INTEGER NOT NULL REFERENCES Segments(segment_id), -- Segmento
    subsegment_id INTEGER REFERENCES SubSegments(subsegment_id), -- Subsegmento
    email VARCHAR(255) NOT NULL, -- E-mail no formato válido
    telephone VARCHAR(15), -- Número de telefone
    state CHAR(2), -- Estado (UF)
    city VARCHAR(40), -- Cidade
    country CHAR(3), -- País (ISO 3166-1 Alpha-3)
    address VARCHAR(50), -- Endereço
    address_number INTEGER, -- Número do endereço
    state_registration VARCHAR(50), -- Inscrição Estadual
    city_registration VARCHAR(50) -- Inscrição Municipal
);

-- Tabela de Produtos de Clientes
CREATE TABLE ClientsProducts (
    product_id SERIAL PRIMARY KEY, -- Chave primária autoincrementada
    product_type VARCHAR(20) NOT NULL CHECK (product_type IN 
        ('Physical Product', 'Digital Product', 'Service')), -- Tipo do produto
    product_description TEXT, -- Descrição do produto
    product_brand VARCHAR(100), -- Marca (preenchida pelo usuário)
    product_price NUMERIC(10, 2) NOT NULL, -- Preço do produto
    product_cat VARCHAR(100), -- Categoria (selecionada pelo usuário)
    product_status VARCHAR(10) NOT NULL CHECK (product_status IN ('Ativo', 'Inativo')), -- Status
    product_license INTERVAL, -- Licença: tempo (anos, meses, dias, horas)
    client_id INTEGER NOT NULL REFERENCES Clients(client_id) ON DELETE CASCADE -- Relacionamento com cliente
);